
# Talk with GPT (WIP)

> **IMPORTANT** 
> It's currently experimental stage yet.

`Talk with GPT` is a chrome extension to "talk" with Chat GPT.

It enables chat GPT by user's own OpenAI API key.
You can ask GPT using your voice.

1. Install extension.
2. Get your OpenAI API Key.
3. Click the icon and set the api key and language.
4. Click `Start conversation` button at the bottom of the extension popup.
5. A modal shows.

API KEY is only stored in your local machine.

TIPS)
To be more like a conversation, ask chat gpt to answer in short sentences.