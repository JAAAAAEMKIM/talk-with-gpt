(() => {
  document.querySelector('#talk-gpt-modal').remove();
  document.querySelector('#talk-gpt-modal-bg').remove();
})();
